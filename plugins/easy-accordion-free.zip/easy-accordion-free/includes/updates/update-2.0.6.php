<?php
/**
 * Update version.
 *
 * @package easy-accordion-free
 */

update_option( 'easy_accordion_free_version', '2.0.6' );
update_option( 'easy_accordion_free_db_version', '2.0.6' );
